<?php
    include 'dbconfig.php';
?>
<?php
  if (isset($_POST['btn-login'])) {
      $email = $_POST['txt_uname_email'];
      $pass = $_POST['txt_password'];

      $sql = mysqli_query($con, "select * from registration where email='$email' and password='$pass'");
      if (mysqli_num_rows($sql)) {
          while ($row = mysqli_fetch_array($sql)) {
              $name = $row['name'];
              $id = $row['usr_id'];
              $type = $row['type'];
              session_start();
              $_SESSION['name'] = $name;
              $_SESSION['id'] = $id;
              $_SESSION['email'] = $email;
              //normal user page
              if ($type == 'NORMAL') {
                  header('location: nuser.php');
              }
              //direction of super admin
              elseif ($type == 'SUPER_ADMIN') {
                  header('location: user.php');
              } elseif ($type == 'ADMIN') {
                  header('location: userr.php');
              }
          }
          //header("location:user.php");
      } else {
          //$error="";
          echo '<script>alert("Wrong username or password, try again!");</script>';
      }
  }

?>
<?php
if (isset($_POST['btn-signup'])) {
    $uname = strip_tags($_POST['txt_uname']);
    $lname = strip_tags($_POST['txt_lname']);
    $contact = strip_tags($_POST['tel_contact']);
    $umail = strip_tags($_POST['txt_umail']);
    $upass = strip_tags($_POST['txt_upass']);
    $usertype = $post_['usertype'];
    $pic = $_FILES['img']['name'];
    $tmp = $_FILES['img']['tmp_name'];
    $type = $_FILES['img']['type'];

    $path = 'profpic/'.$pic;
    $icon = 'warning';
    $class = 'danger';

    if ($uname == '') {
        $error[] = 'provide first name';
    }
    if ($lname == '') {
        $error[] = 'provide last name';
    }
    if ($contact == '') {
        $error[] = 'enter your phone number';
    } elseif ($type == 'application/pdf' || $type == 'application/pdf' || $type == 'application/x-zip-compressed') {
        $error[] = 'this type of file is not supported !';
        echo '<script>alert("unsurported file format");</script>';
    } elseif ($pic == '') {
        $error[] = 'No image selected';
    } elseif ($umail == '') {
        $error[] = 'enter valid email address';
    } elseif (!filter_var($umail, FILTER_VALIDATE_EMAIL)) {
        $error[] = 'Please enter a valid email address';
    } elseif ($upass == '') {
        $error[] = 'provide password';
    } else {
        //$sql="insert into registration values();"
        $sql = mysqli_query($con, "insert into registration(name,lname,contact,email,image,password) values('$uname','$lname','$contact','$umail','$pic','$upass')");
        if ($sql) {
            move_uploaded_file($tmp, $path);
            $error[] = 'Registered successfully';
            echo '<script>alert("Registration was successfully done! proceed to log in...");</script>';
            $icon = 'success';
            $class = 'success';
        }
    }
}

?>
<?php
if (isset($_POST['btn-suggestion'])) {
    $suggestion = strip_tags($_POST['txt_suggestion']);
    $loc = strip_tags($_POST['txt_loc']);
    $reason = strip_tags($_POST['txt_reason']);
    // $party = strip_tags($_POST['txt_party']);
    // $pic=$_FILES["img"]["name"];
    //  $tmp=$_FILES["img"]["tmp_name"];
    //  $type=$_FILES["img"]["type"];
    //  $path="profpic/".$pic;
    // $icon="warning";
    // $class="danger";

    // if($suggestion=="")	{
    // 	$error[] = "provide suggestion";
    // }
    // if($loc=="")	{
    // 	$error[] = "provide location of incidence";
    // }
    // else if($type=="application/pdf" || $type=="application/pdf" || $type=="application/x-zip-compressed")	{
    // 	$error[] = "this type of file does not supported !";
    // 	echo '<script>alert("this type of file does not supported !");</script>';
    // }
    // else if($pic=="")	{
    // 	$error[] = "No Evidence  selected";
    // }
    // else if($carreg=="")	{
    // 	$error[] = "enter car registration number involved";
    // }
    // else if($party=="")	{
    // 	$error[] = "enter parties involved in the suggestion";
    // }

    // else

    //$sql="insert into suggestions values();"
    $sql = mysqli_query($con, "insert into suggestions (suggestion,location,reason) values('$suggestion','$loc','$reason')");
    if ($sql) {
        // move_uploaded_file($tmp,$path);
        // $error[] = "Please retry";
        echo '<script>alert("Your Suggestion was submitted successfully...Thank you ");</script>';
        $icon = 'success';
        $class = 'success';
    }
}

?>
<!DOCTYPE html>
<html lang="en"> 
<head>
<meta charset="utf-8">
<title> Highway Management System</title>
<!-- mobile version -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- CSS -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/green.css" id="colors">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" id="colors">
<body>
 <!--  <div class="container">
    <br />
    <br />
    <br />
    <div class="table-responsive">
      <h2 align="center">Export mysql data to excel</h2><br />
      <div id="live_data"></div></div>
      <form action="excel.php" method="post">
        <input type="submit" name="export_excel" class="btn btn-success" value="export to excel" />
      </form> -->
<div id="wrapper">
<!-- header navigation bar -->
<header class="transparent sticky-header full-width">
<div class="container">
	<div class="sixteen columns">
		<div id="logo" style="margin-top:20px">
			<h1><a href="index.php"><font style="font-size:30px; color:green">Highway Management System</font></a></h1>
		</div>
		<!-- Menu items of the system -->
		<nav id="navigation" class="menu">
      <ul class="float-right">
        <li><a data-toggle = "modal" data-target = "#suggestionModal">Report Suggestion to improve on Highway</a></li>
        <li><a data-toggle = "modal" data-target =  "#signupModal">Sign Up here</a></li>
        <li><a data-toggle = "modal" data-target = "#myModal">Log In here</a></li>
      </ul>
    </nav>

		<!-- Navigation -->
		<div id="mobile-navigation">
		<!-- 	<a href="#menu" class="menu-trigger"><i class="fa fa-reorder"></i> Menu</a> -->
		</div>
	</div>
</div>
</header>
<div class="clearfix"></div>
<!-- background image -->
<div id="banner" class="with-transparent-header parallax background" style="background-image:
 url(images/img9.jpg)" data-img-width="2000" data-img-height="1330" data-diff="300">
	<div class="container">
		<div class="sixteen columns">
			<div class="search-container">
        <div class="announce">
         <strong>Highway Management System</strong>
        </div>
			</div>
		</div>
	</div>
</div>
<!-- modals for login sign up and case/offfence modals.... etc -->
<!-- Modal for login -->
   <div class = "modal fade" id = "myModal" tabindex = "-1" role = "dialog" 
   aria-labelledby = "myModalLabel" aria-hidden = "true">
   <script type='text/javascript' src="js/validation.js"></script>
   <div class = "modal-dialog">
      <div class = "modal-content">
         
         <div class = "modal-header">
            <button type = "button" class = "close" data-dismiss = "modal" aria-hidden = "true">
                 
            </button>
            
            <h4 class = "modal-title" id = "myModalLabel">
               <strong>Hello, Welcome To Highway Management System</strong>
            </h4>
         </div>
         <form class="form-signin" method="post" id="login-form" enctype="multipart/form-data" onsubmit=" return validateLogIn()">
         <div class = "modal-body">
         <input id="email" type="email" name="txt_uname_email" placeholder="enter email address" required />
         </div>
         <div class = "modal-body">
            <input id="pass" type="password" name="txt_password" placeholder="password" required />
         </div>
         
         <div class = "modal-footer">
           <a href="#" class="list-group-item">Forgot Password? Reset here
             <p id='messagelogin'></p>
                <p id='message2'></p>
            <input type = "submit" class = "btn btn-primary" name="btn-login" value="LOG IN">
               
            </input>
			<button type = "button" class = "btn btn-default" data-dismiss = "modal">
               Close
            </button>
            
        </form>
         </div>
         
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
  
</div><!-- /.modal -->

<!-- Modal for sign up -->
<div class = "modal fade" id = "signupModal" tabindex = "-1" role = "dialog" 
   aria-labelledby = "myModalLabel" aria-hidden = "true">
     <script type='text/javascript' src="js/validation.js"></script>
   <div class = "modal-dialog">
      <div class = "modal-content">  
         <div class = "modal-header">
            <button type = "button" class = "close" data-dismiss = "modal" aria-hidden = "true">
                  
            </button>
            
            <h4 class = "modal-title" id = "myModalLabel">
              <strong>Welcome to Highway Management System Sign Up Page</strong>
            </h4>
             <form method="post" class="form-signin" enctype="multipart/form-data" onsubmit=" return validateRegister()">
           <!--  <form method="post" class="form-signin" enctype="multipart/form-data" > -->
         </div>
         <div class = "modal-body">
           First Name: <input id="name" type="text" name="txt_uname" placeholder="enter your first name" required/>
         </div>
         <div class = "modal-body">
            last Name: <input id="lname" type="text" name="txt_lname" placeholder="enter your last name" required/>
         </div>
          <div class = "modal-body">
            Phone number <input id="phone" type="text" name="tel_contact" placeholder="Enter correct phone number" required/>
         </div>
         <div class = "modal-body">
            Email : <input type="email" name="txt_umail" placeholder="enter  email here" required/>
         </div>
         <div class = "modal-body">
            Password: <input type="password" name="txt_upass" placeholder="enter  password" required/>
         </div>
         <div class = "modal-body">
            Add profile picture: <input type="file" name="img" required/>
         </div>
         <div class = "modal-footer">
                <p id='messagesignup'></p>
                <p id='message2'></p>
            <input type = "submit" class = "btn btn-primary" value="SIGN UP" name="btn-signup">
			 <button type = "button" class = "btn btn-default" data-dismiss = "modal">
               Close
            </button>
           
		   
            </input>
         </div>
         </form>
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
  
</div><!-- /.modal -->

<!-- Modal for suggestion reporting -->
<div class = "modal fade" id = "suggestionModal" tabindex = "-1" role = "dialog" 
   aria-labelledby = "myModalLabel" aria-hidden = "true">
   
   <div class = "modal-dialog">
      <div class = "modal-content">
         
         <div class = "modal-header">
            <button type = "button" class = "close" data-dismiss = "modal" aria-hidden = "true">
            </button>
            
            <h4 class = "modal-title" id = "myModalLabel">
            Report Your Suggestion Here:
            </h4>
            <form method="post" class="form-signin" enctype="multipart/form-data">
         </div>
         <div class = "modal-body">
            Type of suggestion <input type="text" name="txt_suggestion" placeholder="Like Contruction Of Road Pumps" required/>
         </div>
         
         <div class = "modal-body">
            Location of suggestion<input type="text" name="txt_loc" placeholder="Name Of Location Of Suggestion Like (Nakuru)" required/>
         </div>
         <div class = "modal-body">
            Reason for the suggestion<input type="text" name="txt_reason" placeholder="Like If There has Been Frequent Accidents" required/>
         </div>
        <!--  <div class = "modal-body">
            parties involved<input type="text" name="txt_party" placeholder="like between police and driver" required/>
         </div> -->
        <!--  <div class = "modal-body">
            Evidence in picture or video format: <input type="file" name="img" required/>
         </div> -->
         <div class = "modal-footer">
            
            <input type = "submit" class = "btn btn-primary" value="Submit your Suggestion" name="btn-suggestion">
			 <button type = "button" class = "btn btn-default" data-dismiss = "modal">
               Close
            </button>
            </input>
         </div>

         </form>
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
  
</div><!-- /.modal -->
<!-- end -->
<div class="container">
	<!-- Recent Jobs -->
	<h5 class="text-center"><strong>Information and Updates on Recent ongoing Highway contructions Kenya.</strong></h5>
	<div class="eleven columns">
	<div class="padding-right">
		<ul class="job-list full">
			<?php
           $sql = mysqli_query($con, 'select * from posts join registration where posts.usr_id_p=registration.usr_id order by posts.date desc limit 1,6');
                             while ($row = mysqli_fetch_array($sql)) {
                                 $title = $row['Contractor_highway'];
                                 $des = $row['descriptions'];
                                 $status = $row['cost_of_highway'];
                                 $img = $row['image'];
                                 $name = $row['name'];
                                 $time = $row['name'];
                                 $time_ago = $row['date'];
                                 echo '<li><a href="#">';
                                 echo '<img src="profpic/'.$img.'" alt="">';
                                 echo '<div class="job-list-content">';
                                 echo '<h4>'.$title.'</h4>';
                                 echo '<h4>'.$des.'</h4>';
                                 echo '<h4>'.$status.'</h4>';
                                 echo '</div>';
                                 echo '<div class="job-icons" style="margin-left:100px">';
                                 echo '</div>';
                                 echo '</a>';
                                 echo '<a data-toggle = "modal" data-target = "#myModal" class="btn btn-default" >Report any issue or give Feedback with this ongoing Highway contruction here</a>';
                                 echo '<br/><br/>';
                                 echo '</li>';
                             }
           ?>
			
		</ul>
		<div class="clearfix"></div>
		<div class="pagination-container">	
		</div>
	</div>
	</div>
    <!-- Widgets -->
  <div class="five columns">
          
    <!-- Alerrt type-->
    <div class="widget">
      <h5 style="background-color:DodgerBlue;">Highway Contruction Reports Progress and announcements: </h5>

      <ul class="checkboxes">
        <li>
    <ul class="job-list full">
      <?php
           $sql = mysqli_query($con, 'select * from alerts');
                             while ($row = mysqli_fetch_array($sql)) {
                                 $ti = $row['alert_date'];
                                 $title = $row['title'];
                                 $des = $row['descriptions'];
                                 echo '<li><a href="#">';
                                 echo '<h5>'.$ti.'</h5>';
                                 echo '<h5>'.$title.'</h5>';
                                 echo '<h5>'.$des.'</h5>';
                             }
           ?>
      
    </ul>
    <div class="pagination-container">  
    </div>
        </li>
        
      </ul>

    </div>
  </div>
  <!-- Widgets / End -->
</div>

<!-- scripts -->
<script src="scripts/jquery-2.1.3.min.js"></script>
<script src="scripts/custom.js"></script>
<script src="scripts/jquery.superfish.js"></script>
<script src="scripts/jquery.themepunch.tools.min.js"></script>
<script src="scripts/jquery.themepunch.revolution.min.js"></script>
<script src="scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="scripts/jquery.flexslider-min.js"></script>
<script src="scripts/chosen.jquery.min.js"></script>
<script src="scripts/jquery.magnific-popup.min.js"></script>
<script src="scripts/waypoints.min.js"></script>
<script src="scripts/jquery.counterup.min.js"></script>
<script src="scripts/jquery.jpanelmenu.js"></script>
<script src="scripts/stacktable.js"></script>
<script src="scripts/headroom.min.js"></script>
<script src="bootstrap/jquery-3.2.1.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>		
</div>
<div>
<footer>
        <label style="Text-align:centre;">&copy;2021 </label><br>
        <label style="Text-align:centre;">contacts:0746442202 </label><br>
        <label id="ad" style="Text-align:centre;" ><a href="#">Created Festus kipkorir </a></label>
        <script type="text/javascript" src='js/menuToggle.js'></script>
</footer>
</body>
</html>
