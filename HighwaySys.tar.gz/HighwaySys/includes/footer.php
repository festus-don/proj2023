<footer>
<label style="float:right";> &copy;2021 </label><br>
        <label style="float:right";>contacts:0746442202 </label><br>
        <label id="ad" style="Text-align:centre;" ><a href="#">Created Festus kipkorir </a></label>
        <script type="text/javascript" src='js/menuToggle.js'></script>
        
</footer>
