-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2021 at 08:38 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `htms`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `alert_id` int(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `descriptions` varchar(100) NOT NULL,
  `alert_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`alert_id`, `title`, `descriptions`, `alert_date`) VALUES
(20, 'Nairobi will be under maintenance', 'Use The westlands divers', '2020-12-03'),
(21, 'Mombasa Highway ', 'Under Engineer JK', '2020-12-17');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `applic_id` int(10) NOT NULL,
  `post_id_c` int(10) NOT NULL,
  `user_id_c` int(10) NOT NULL,
  `complain_comment` varchar(200) NOT NULL,
  `feedback_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`applic_id`, `post_id_c`, `user_id_c`, `complain_comment`, `feedback_time`) VALUES
(53, 63, 52, 'The contractor is delaying and demolishing vipanda', '2020-10-30 15:29:34'),
(55, 62, 52, 'yes there', '2020-11-01 13:50:04'),
(56, 66, 6, '', '2020-11-01 13:56:06'),
(57, 66, 6, 'the contactor is sloww', '2020-11-01 14:01:27'),
(58, 66, 52, 'the road is of poor quality', '2020-11-01 14:02:15'),
(59, 62, 52, 'neeed that', '2020-11-01 14:03:23'),
(60, 66, 52, 'wawa', '2020-11-01 14:05:56'),
(61, 66, 52, 'The contractor is slow and road is poor', '2020-11-01 14:22:45'),
(62, 66, 52, 'ok', '2020-11-01 14:29:23'),
(63, 66, 52, 'The contractor is demolishing houses ', '2020-11-13 08:41:14'),
(64, 67, 54, 'The  ', '2020-12-03 07:53:00'),
(65, 67, 54, 'The contractor is demolishing stalls', '2020-12-03 07:58:40'),
(66, 67, 54, 'yes yes good work', '2020-12-03 08:03:07'),
(67, 67, 54, 'nooo', '2020-12-03 08:04:55'),
(68, 67, 54, 'expensive', '2020-12-03 08:06:35'),
(69, 70, 54, 'The contractor is slow', '2020-12-17 07:37:38');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `noti_id` int(10) NOT NULL,
  `pos_id` int(10) NOT NULL,
  `post_usr` int(10) NOT NULL,
  `cont_user` int(10) NOT NULL,
  `name_des_company` varchar(200) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`noti_id`, `pos_id`, `post_usr`, `cont_user`, `name_des_company`, `time`) VALUES
(47, 61, 6, 52, 'Comment', '2020-10-30 11:50:11'),
(49, 66, 6, 52, 'the road is baddd', '2020-11-01 14:25:39');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(10) NOT NULL,
  `usr_id_p` int(10) NOT NULL,
  `Contractor_highway` varchar(200) NOT NULL,
  `cost_of_highway` varchar(345) NOT NULL,
  `descriptions` varchar(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `contact` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `usr_id_p`, `Contractor_highway`, `cost_of_highway`, `descriptions`, `date`, `contact`) VALUES
(67, 6, 'Litein Highway', 'Ksh 300 Million', 'A34 Class road type', '2020-12-03', '0790333119'),
(68, 6, 'Nairobi Highway Under JM Contractors Limited', 'Ksh 345 Million', 'A45 Road Type class', '2020-12-03', '0789567890'),
(69, 6, 'Mombasa Highway', 'Ksh 45Million', 'C23 Road Type', '2020-12-03', '0756745632'),
(70, 6, 'Nakuru highway under contractor KK', '45 Million', 'E34 ', '2020-12-17', '07905663456');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `usr_id` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(250) NOT NULL DEFAULT 'No picture uploaded',
  `password` varchar(250) NOT NULL,
  `type` varchar(20) DEFAULT 'NORMAL',
  `forgot_pass_identity` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`usr_id`, `name`, `lname`, `contact`, `email`, `image`, `password`, `type`, `forgot_pass_identity`) VALUES
(6, 'festus', 'kipkorir', '0790333119', 'festuskipkorir01@gmail.com', 'FB_IMG_1554028405986.jpg', 'festuskipkorir01@gmail.com', 'SUPER_ADMIN', ''),
(7, 'jeff', 'bett', '0728253131', 'jeff@gmail.com', 'FB_IMG_1554818474240.jpg', 'jeff@gmail.com', 'ADMIN', ''),
(51, 'Charles', 'Kirui', '0790333119', 'kirui@gmail.com', 'FB_IMG_1553622575904.jpg', 'kirui@gmail.com', 'ADMIN', ''),
(52, 'frank', 'bett', '0723024372', 'frankbett@gmail.com', 'FB_IMG_1556517969114.jpg', 'frankbett@gmail.com', 'NORMAL', ''),
(54, 'Domi', 'bett', '0743904937', 'domibett@gmail.com', 'FB_IMG_1556518177877.jpg', 'domibett@gmail.com', 'ADMIN', ''),
(55, 'pius', 'pkor', '0789456345', 'piuspkor@gmail.com', 'FB_IMG_1554028405986.jpg', 'piuspkor@gmail.com', 'ADMIN', ''),
(56, 'victor', 'Mwatu', '0789089679', 'mwatu@gmail.com', 'FB_IMG_1554818469770.jpg', 'mwatu@gmail.com', 'NORMAL', ''),
(61, 'erik', 'lamela', '0790567453', 'lamela@gmail.com', 'FB_IMG_1554818469770.jpg', 'password_hash(lamela@gmail.com, PASSWORD_DEFAULT)', 'NORMAL', ''),
(62, 'maureen', 'kamau', '0791816484', 'maureen@gmail.com', 'FB_IMG_1554028403102.jpg', 'maureen', 'NORMAL', '');

-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE `suggestions` (
  `suggestion_id` int(10) NOT NULL,
  `suggestion` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `reason` varchar(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suggestions`
--

INSERT INTO `suggestions` (`suggestion_id`, `suggestion`, `location`, `reason`, `date`) VALUES
(24, 'Need a road bump ', 'the nakuru Litein Highway', 'Overspededing cars knocks people down', '2020-10-28'),
(25, 'Construct road lights ', 'At molo Highway', 'The dark road ful of thugs', '2020-10-28'),
(26, 'Construct road lights ', 'At molo Highway', 'The dark road ful of thugs', '2020-10-28'),
(27, 'We need road pumps to be contrcuted', 'At Nakuru eldoret road', 'The frequent accidents and  overspeeding', '2020-10-28'),
(28, 'Re tarnaing of the road needed', 'Elburgon road', 'Impassable', '2020-10-28'),
(29, 'Needed road Bump creation', 'Molo Primary School', 'There are many school going children in the area', '2020-10-30'),
(30, 'We need a diversion tarmacked', 'Location is Litein', 'in times of rainfall we have impassable road', '2020-10-30'),
(31, 'We need a Construction of road Bump', 'Elburgon primary highway ', 'The safety of the kids needed...', '2020-10-30'),
(32, 'A diversion need be tarmacked ', 'In eldoret Junction', 'It is impassable during rainy seasons', '2020-11-11'),
(33, 'Need a road pump to be bilud', 'Njoro Primary', 'Brcause of frequent road knocks', '2020-12-17'),
(34, 'victor', 'victor', 'victor', '2021-02-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`alert_id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`applic_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`noti_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`usr_id`);

--
-- Indexes for table `suggestions`
--
ALTER TABLE `suggestions`
  ADD PRIMARY KEY (`suggestion_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `alert_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `applic_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `noti_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `usr_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `suggestions`
--
ALTER TABLE `suggestions`
  MODIFY `suggestion_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
