<?php
require_once "dbconfig.php";
session_start();

class handler extends DBConnect{
    
    private $alertLoggedIn = "<script>alert('You need to be logged in');</script>";
    
    function modal($mess, $redirectTo){
        echo "<div class='modal'>
            <div class='modal_content'>
                <p>$mess</p>
                <button><a href='$redirectTo'>Okay</a></button>
            </div>
        </div>";
    }
    
    function checkLoggedIn(){
        if(isset($_SESSION['id'])){
            return true;
        }
        return false;
    }
    
    function goToPage($url){
        echo "<script>window.open('$url','_self');</script>";
    }
    
    function logIn(){
        $id = $_POST['id'];
        $pass = $_POST['password'];
        
        $query = "SELECT * from ".$this->database.".members WHERE id=?";
        
        $result = $this->connect()->prepare($query);
        
        $result->execute([$id]);
        if($result->rowCount() == 0){
            header("Location:../login.php?usererr=true");
        }else{
            while($row = $result->fetch()){
                if(password_verify($pass, $row['password'])){
                    session_start();
                    $_SESSION['fname'] = $row['fname'];
                    $_SESSION['id'] = $id;
                    $_SESSION['type']=$row['type'];
                    header("Location:../index.php");
                }else{
                    
                }
            }
            $this->goToPage("../login.php?passerr=true");
            
        }
    }
    
    function register(){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $id = $_POST['id'];
        $phone = $_POST['phone'];
        $password = $_POST['pass'];
        
        $query = "SELECT * FROM ".$this->database.".members WHERE id = ?";
        $result = $this->connect()->prepare($query);
        
        $result->execute([$id]);
        if($result->rowCount()){
            header("Location:../register.php?id=true");
        }
        
        $query = "SELECT * FROM ".$this->database.".members WHERE phone = ?";
        $result = $this->connect()->prepare($query);
        
        $result->execute([$phone]);
        if($result->rowCount()){
            header("Location:../register.php?phone=true");
        }
        
        $query = "INSERT INTO ".$this->database.".members (fname, lname, id, phone, password) VALUES(?,?,?,?,?)";
        
        $result = $this->connect()->prepare($query);
        $result->execute([$fname, $lname, $id, $phone, password_hash($password, PASSWORD_DEFAULT)]);
        
        header("Location:../login.php?reg=true");
    }

    function postAdd(){
        if(!$this->checkLoggedIn()){
            $this->modal("You need to be logged in for you to access this page", "../sell.php?&mess=false");
        }else{
            $status = "PENDING";
            $type = $_POST['type'];
            $breed = $_POST['breed'];
            $location = $_POST['location'];
            $age = $_POST['age'];
            $price = $_POST['price'];
            $additional = $_POST['additional'];
            $code = $_POST['code'];
            $number = $_POST['number'];

            $fail = 0;
            $uploaded = "";
            $query = "SELECT * FROM ".$this->database.".posts";
            $result = $this->connect()->query($query);
            while($row=$result->fetch()){
                $p_id = $row['p_id'];    
            }
            $p_id = ((int)$p_id)+1;
            echo " int-> ".$p_id;
            $num = count($_FILES['image']['name']);
            for($i = 0;$i<count($_FILES['image']['name']) ;$i++){
                $target_dir = "../images/";
                $ext = strtolower(end(explode('.',$_FILES['image']['name'][$i])));
                $name = $p_id."_".$i.".".$ext;
                $target_file = $target_dir.basename($name);
                if($target_file == $target_dir){
                    continue;
                }
                if(move_uploaded_file($_FILES['image']["tmp_name"][$i], $target_file)){
                    $uploaded = $uploaded.$ext.",";
                }else{
                    $fail = 1;;
                }
            }

            $query = "INSERT INTO ".$this->database.".posts (type, breed, location, age, price, comments, image, id, mpesa_code, status, number) VALUES(?,?,?,?,?,?,?,?,?,?,?)";



            $result = $this->connect()->prepare($query);
            $result->execute([$type, $breed, $location, $age, $price, $additional, $uploaded, $_SESSION['id'], $code, $status, $number]);

            if($fail == 1){
                header("Location:../sell.php?failPost=true");
            }else{
                header("Location:../sell.php?successPost=true");
            } 
        }
        
    }
    
    function closed(){
        $state = "CLOSED";
        $id = $_POST['i_id'];
        $query = "UPDATE ".$this->database.".interested SET state = ? WHERE id = ?";
        
        $result = $this->connect()->prepare($query);
        
        $result->execute([$state, $id]);
        header("Location:../AdminInterested.php");
    }
    
    function paid(){
        $state = "APPROVED";
        $id = $_POST['p_id'];
        $query = "UPDATE ".$this->database.".posts SET status = ? WHERE p_id = ?";
        
        $result = $this->connect()->prepare($query);
        
        $result->execute([$state, $id]);
        header("Location:../AdminView.php");
    }
    
    function declined(){
        $state = "DECLINED";
        $id = $_POST['p_id'];
        $query = "UPDATE ".$this->database.".posts SET status = ? WHERE p_id = ?";
        
        $result = $this->connect()->prepare($query);
        
        $result->execute([$state, $id]);
        
        header("Location:../AdminView.php");
    }
    
    function interested(){
        $p_id = $_POST['p_id'];
        if(!$this->checkLoggedIn()){
            echo $this->alertLoggedIn;
            echo "<script>window.open('../viewPost.php?p_id=$p_id&mess=false','_self');</script>";
        }else{
            $id = @$_SESSION['id'];
            $query = "SELECT * FROM ".$this->database.".members WHERE id = ?";
            $result = $this->connect()->prepare($query);
            $result->execute([$id]);

            $row = $result->fetch();

            $phone = $row['phone'];

            $query = "INSERT INTO ".$this->database.".interested (user_id, p_id, phone, state) VALUES(?,?,?,?)";

            $result = $this->connect()->prepare($query);

            $result->execute([$id, $p_id, $phone, "OPEN"]);
             header("Location:../viewPost.php?p_id=$p_id&successOrder=true");
        }        
       
    }

    function logout(){
        session_destroy();
        session_unset();
        header('Location:../index.php');
    }

    function AdminPost(){
        $status = "APPROVED";
        $type = $_POST['type'];
        $breed = $_POST['breed'];
        $location = $_POST['location'];
        $age = $_POST['age'];
        $price = $_POST['price'];
        $additional = $_POST['additional'];
        $number = $_POST['number'];
        
        $fail = 0;
        $uploaded = "";
        $query = "SELECT * FROM ".$this->database.".posts";
        $result = $this->connect()->query($query);
        $p_id = $result->rowCount();
        
        $num = count($_FILES['image']['name']);
        for($i = 0;$i<count($_FILES['image']['name']) ;$i++){
            $target_dir = "../images/";
            $ext = strtolower(end(explode('.',$_FILES['image']['name'][$i])));
            $name = $p_id."_".$i.".".$ext;
            $target_file = $target_dir.basename($name);
            if($target_file == $target_dir){
                continue;
            }
            if(move_uploaded_file($_FILES['image']["tmp_name"][$i], $target_file)){
                $uploaded = $uploaded.$ext.",";
            }else{
                $fail = 1;;
            }
        }

        $query = "INSERT INTO ".$this->database.".posts (type, breed, location, age, price, comments, image, id, status, number) VALUES(?,?,?,?,?,?,?,?,?,?)";
        
        
        
        $result = $this->connect()->prepare($query);
        $result->execute([$type, $breed, $location, $age, $price, $additional, $uploaded, $_SESSION['id'], $status,$number]);
        
        if($fail == 1){
            header("Location:../AdminPost.php?failPost=true");
        }else{
            header("Location:../AdminPost.php?successPost=true");
        }
    }

    function RemoveMember(){
        $id = $_POST['id'];
        
        $query = "DELETE FROM ".$this->database.".members WHERE id=?";
        $result = $this->connect()->prepare($query);
        $result->execute([$id]);
        
        header("Location:../AdminMembers.php");
    }
    
    function MakeAdmin(){
        $id = $_POST['id'];
        
        $query = "UPDATE ".$this->database.".members SET type= ? WHERE id=?";
        $result = $this->connect()->prepare($query);
        $result->execute(["ADMIN",$id]);
        
        header("Location:../AdminMembers.php");
    }
    
    function RemoveAdmin(){
        $id = $_POST['id'];
        
        $query = "UPDATE ".$this->database.".members SET type= ? WHERE id=?";
        $result = $this->connect()->prepare($query);
        $result->execute(["NORMAL",$id]);
        
        header("Location:../AdminMembers.php");
    }
}
            

$handle = new handler();
if(isset($_POST['login'])){
    $handle->logIn();
}

if(isset($_POST['register'])){
    $handle->register();
}

if(isset($_POST['post'])){
    $handle->postAdd();
}

if(isset($_POST['interested'])){
    $handle->interested();
}

if(isset($_POST['closed'])){
    $handle->closed();
}

if(isset($_POST['approve'])){
    $handle->paid();
}

if(isset($_POST['decline'])){
    $handle->declined();
}

if(isset($_POST['logout'])){
    $handle->logout();
}

if(isset($_POST['remove'])){
    $handle->AdminRemove();
}

if(isset($_POST['makeAdmin'])){
    $handle->MakeAdmin();
}

if(isset($_POST['removeAdmin'])){
    $handle->RemoveAdmin();
}

if(isset($_POST['postAdmin'])){
    $handle->AdminPost();
}

?>