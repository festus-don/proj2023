<?php
session_start();
include'dbconfig.php';
// checking session is valid for not 
// if (strlen($_SESSION['usr_id']==0)) {
//   header('location:logout.php');
//   }
?>
<?php
 if (isset($_POST['search']))
  {
   $txtStartDate=$_POST['txtStartDate'];
   $txtEndDate=$_POST['txtEndtDate'];
   
   $query=mysqli_query($con,"Select suggestion from suggestions Where date Between DATE('$txtStartDate') and DATE('$txtEndDate') order by date");
   // $query = mysqli_query($con,"select * from suggestions");
   $count=mysqli_num_rows($query);
   // echo $count;
   // die();
 }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Highway Management sysem</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
     <script> 
        function printDiv() { 
          var t= new Date();
            var divContents = document.getElementById("row").innerHTML; 
            var a = window.open('', '', 'height=500, width=500'); 
           
            a.document.write('<html>'); 
            a.document.write('<link rel="stylesheet" href="css/print.css" type="text/css" />'); 
            // a.document.write('<body > <center><h1>Blood Requests Report<h1><center> <br>');
            a.document.write(t); 
            a.document.write(divContents); 
            a.document.write('</body></html>'); 
            setTimeout(function(){ a.print();},1000);
            a.document.close(); 

        } 
    </script> 
  </head>

  <body>

  <section id="container" >
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <a href="#" class="logo"><b><h4>Highway management system Road users suggestions</b></h4></a>
            <div class="nav notify-row" id="top_menu">
               
                         
                   
                </ul>
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <aside>
          <div id="sidebar"  class="nav-collapse ">
            <ul class="sidebar-menu" id="nav-accordion">
                  <p class="centered"><a href="#"><img src="assets/img/img3.jpg" class="img-circle" width="60"></a></p>
                 
                <li class="sub-menu">
                      <a href="viewsuggestions.php" >
                          <span>view Reported suggestions</span>
                      </a>
                      <a href="addadminroles.php" >
                          <span>Add admin roles</span>
                      </a>
                     <a href="husers.php">
                          <span>Contractors and respective roads</span>
                      </a>
                     <!--  <a href="husers.php">
                          <span>Settled suggestions and details</span>
                      </a> -->
                       <!--  <a href="applicationtasks.php" >
                          <span>Applications for tasks posted</span>
                      </a> -->
                  </li>
              
                 
              </ul>
          </div>
      </aside>
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i>Road suggestion raised by users:</h3>
				<div class="row" id="row">
				
                  
	                  
                  <div class="col-md-12">
                      <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
	                  	  	  <h4><i class="fa fa-angle-right"></i> The Highway suggestions Reports</h4>
                          
                            <!-- <center>
                             
                              <hr/>
                           
                              </form>
                            </center> -->
	                  	  	  <hr>
                              <thead>
                              <tr>
                                  <th>Number</th>
                                  <th>Kind Of Suggestion</th>
                                  <th>Suggestion's location</th>
                                  <th>Reason for suggestions</th>
                                  <th>Date of report</th>
                                  <!-- <th>Amount Charged.(Ksh.)</th> --> 
                                <!--   <th>Mode of pay</th>
                                  <th>Charge</th> -->
                              </tr>
                              </thead>
                              <tbody>
                              <?php $ret=mysqli_query($con,"select * from suggestions");
							               $cnt=1;
							                while($row=mysqli_fetch_array($ret))
							                {
                                ?>
                              <tr>
                              <td><?php echo $cnt;?></td>
                                  <td><?php echo $row['suggestion'];?></td>
                                  <td><?php echo $row['location'];?></td>
                                  <td><?php echo $row['reason'];?></td>
                                  <td><?php echo $row['date'];?></td>
                                  
                                   <td>
                                     
                                    <!--  <a href="prosecute.php?suggestion_id=<?php echo $row['suggestion_id'];?>"> 
                                     <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a> -->
                                  </td>
                              </tr>
                              <?php $cnt=$cnt+1; }
                              ?>
                             
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
               <div class="container">
    <br />
    <br />
    <br />
    <div class="table-responsive">
      <div id="live_data"></div></div>
      <!-- <form action="excelS.php" method="post"> -->
        <input type="submit" name="" class="btn btn-success"id="print"  value="Print Reports" onclick="printDiv()" />

      </form>
		</section>
      </section
  ></section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
<?php  
?>