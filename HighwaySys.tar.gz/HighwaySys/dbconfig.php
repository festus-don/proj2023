<?php

$con = mysqli_connect('localhost', 'root', '', 'htms');
//$con=mysqli_connect("localhost","root"," ","Htms") or die(mysqli_error());
error_reporting(1);
?>

