<?php
$con=mysqli_connect("localhost","root","","Htms");
$output = '';
if(isset($_POST["export_excel"]))
{
	 // <?php $ret=mysqli_query($con,"select * from suggestions");
	// $sql = "select * from posts ORDER BY id DESC";
	$ret=mysqli_query($con,"select * from posts");
	if(mysqli_num_rows($ret) > 0)
	{
		$output .= '
       <table class="table" bordered="1">
                <tr>
               
                <th>Contractor_highway</th>
                <th>cost_of_highway</th>
                 <th>date</th>

                </tr>

		';
		while($row = mysqli_fetch_array($ret))
		{
			$output .= '
             <tr>
                 
                 <td>'.$row["Contractor_highway"].'</td>
                 <td>'.$row["cost_of_highway"].'</td>
                 <td>'.$row["date"].'</td>

             </tr>

			';
		}
		$output .= '</table>';
		header("Content-Type: application/xls");
		header("Content-Disposition:attachment; filename=download.xls");
		echo $output;
	}
}
?>